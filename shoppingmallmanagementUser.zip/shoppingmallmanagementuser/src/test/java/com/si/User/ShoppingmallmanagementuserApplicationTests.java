package com.si.User;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallmanagementuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
