package com.si.User;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingmallmanagementuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingmallmanagementuserApplication.class, args);
	}

}
